# r2gitsync
Sync 1C repository to git. Written on golang
